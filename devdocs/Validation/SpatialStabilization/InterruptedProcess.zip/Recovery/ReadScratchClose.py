"""Read only the timed campaign scratch directory's create/close records from NTFS."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import struct


Area = Path("C:/Sandbox/GargantuanSpatialStabilizationPerformance-20261128/Repaired")
Scratch = Area / "FixedScratch"
Parent = Scratch.stat().st_ino
K = ctypes.WinDLL("kernel32", use_last_error=True)
K.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                          wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
K.CreateFileW.restype = wintypes.HANDLE
K.DeviceIoControl.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                             ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
K.DeviceIoControl.restype = wintypes.BOOL
K.CloseHandle.argtypes = [wintypes.HANDLE]
K.GetCurrentProcess.restype = wintypes.HANDLE
K.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]
K.SetProcessAffinityMask(K.GetCurrentProcess(), 1 << 8)
Handle = K.CreateFileW("C:\\", 0x80, 7, None, 3, 0x02000000, None)
if Handle == ctypes.c_void_p(-1).value:
    raise ctypes.WinError(ctypes.get_last_error())


def Control(Code, Data=b"", Size=8192):
    Out = ctypes.create_string_buffer(Size)
    Got = wintypes.DWORD()
    if not K.DeviceIoControl(Handle, Code, Data if Data else None, len(Data), Out, Size, ctypes.byref(Got), None):
        raise ctypes.WinError(ctypes.get_last_error())
    return Out.raw[:Got.value]


def Read(Position, Size=16384):
    Data = struct.pack("<qIIQQQHH4x", Position, 0xffffffff, 0, 0, 0, Journal, 2, 3)
    Out = Control(0x903ab, Data, Size)
    if len(Out) < 8:
        raise ValueError("Missing journal cursor")
    Cursor = struct.unpack_from("<q", Out)[0]
    Records = []
    I = 8
    while I < len(Out):
        Length, Major, Minor = struct.unpack_from("<IHH", Out, I)
        if Length == 0 or I + Length > len(Out):
            raise ValueError("Damaged journal record")
        if Major in (2, 3):
            IdBytes = 8 if Major == 2 else 16
            Ref = int.from_bytes(Out[I+8:I+8+IdBytes], "little")
            ParentRef = int.from_bytes(Out[I+8+IdBytes:I+8+2*IdBytes], "little")
            Usn, Timestamp, Reason = struct.unpack_from("<qqI", Out, I+8+2*IdBytes)
            Name = ""
            if ParentRef == Parent:
                N, Offset = struct.unpack_from("<HH", Out, I+40+2*IdBytes)
                Name = Out[I + Offset:I + Offset + N].decode("utf-16le")
            Records.append((Usn, Timestamp, ParentRef, Ref, Reason, Name))
        I += Length
    return Cursor, Records


Start = int(datetime(2026, 11, 28, 7, 32, 55, tzinfo=timezone.utc).timestamp()) * 10_000_000 + 116444736000000000
End = Start + 5 * 10_000_000
try:
    Journal, First, Next = struct.unpack_from("<Qqq", Control(0x900f4))
    # USN of the interrupted process's own retained project.json file.
    Cursor = 0x00000022840db5e8
    if Cursor < First or Cursor >= Next:
        raise ValueError("The retained project file's journal position has expired")
    Matches = []
    BytesReadUpper = 0
    while Cursor < Next and BytesReadUpper < 3_000_000:
        After, Records = Read(Cursor,65536)
        BytesReadUpper += 65536
        if After <= Cursor:
            break
        for Usn, Stamp, ParentRef, Ref, Reason, Name in Records:
            if ParentRef == Parent and Start <= Stamp <= End:
                Second, Fractions = divmod(Stamp-116444736000000000, 10000000)
                Utc = datetime.fromtimestamp(Second,timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")+f".{Fractions:07d}Z"
                Matches.append(dict(Utc=Utc,Usn=hex(Usn),Reference=hex(Ref),Reason=hex(Reason),Name=Name))
        if Records and Records[-1][1] > End+10_000_000:
            break
        Cursor=After
    if not Matches:
        raise ValueError("The time span or owned-directory records were unavailable")
    Output=dict(ParentPath=Scratch.as_posix(),ParentFileReference=hex(Parent),Journal=hex(Journal),
                Records=Matches)
    (Area / "ScratchClose.json").write_text(json.dumps(Output,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(Output))
finally:
    K.CloseHandle(Handle)
