from pathlib import Path
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import shutil
import struct
import zlib


Base = Path("C:/Sandbox/GargantuanSpatialStabilizationPerformance-20261128/Repaired")
Original = Base / "Fixed-ordinary"
Closed = Base / "ClosedPrefix"
Closed.mkdir()
Finished = Base / "Completion"
Finished.mkdir()
Summary = (Original / "Processes.csv").read_bytes()
Stream = (Original / "Ticks.csv.gz").read_bytes()
Decoder = zlib.decompressobj(wbits=31)
Data = Decoder.decompress(Stream) + Decoder.flush()
if Decoder.eof or Decoder.unused_data or not Data.endswith(b"\r\n"):
    raise ValueError("Expected the collector's interrupted, flushed gzip stream")
Tail = b"\x03\x00" + struct.pack("<II", zlib.crc32(Data), len(Data) & 0xffffffff)
if gzip.decompress(Stream + Tail) != Data:
    raise ValueError("A finalized copy failed byte-for-byte decompression")
OriginalRows = list(csv.DictReader(io.StringIO(Summary.decode())))
Samples = list(csv.DictReader(io.StringIO(Data.decode())))
if len(Samples) != len(OriginalRows) or len(Samples) != 139:
    raise ValueError("The prefix lengths differ or the observed boundary changed")
for Row, OriginalRow in zip(Samples, OriginalRows):
    if any(Row[Key] != OriginalRow[Key] for Key in ("Block", "Run", "Profile")):
        raise ValueError("Position mismatch in the interrupted source")
    Ticks = [int(T) for T in Row["StepNanoseconds"].split()]
    Groups = [tuple(map(int, Group.split(":"))) for Group in Row["OmittedGroupsStartCountTotal"].split()]
    if len(Ticks) != int(OriginalRow["Exact"]) or sum(Ticks) + sum(T for _, _, T in Groups) != int(OriginalRow["EngineStepNs"]):
        raise ValueError("Observed native accounting changed")
if (Samples[-1]["Block"], Samples[-1]["Run"]) != ("35", "3"):
    raise ValueError("The completed prefix does not end at scheduled position 139")
(Closed / "Processes.csv").write_bytes(Summary)
(Closed / "Ticks.csv.gz").write_bytes(Stream + Tail)
shutil.copyfile(Base / "FixedEvents.jsonl", Finished / "FixedEvents.jsonl")
Hash = lambda Bytes: hashlib.sha256(Bytes).hexdigest()
Receipt = {
    "AdministrativeInterruption": "The app turn was interrupted during scheduled position 140. No completed row was available for that position.",
    "OriginalStartUtc": "2026-11-28T07:05:55.5916619Z",
    "LastCompleteOriginalRowFileWriteUtc": "2026-11-28T07:32:56.3608287Z",
    "CollectorAbsentObservedUtc": "2026-11-28T07:33:27.8986313Z",
    "PrefixVerifiedUtc": datetime.now(timezone.utc).isoformat(),
    "ScheduledPositionsRetained": len(Samples),
    "LastCompleted": {"Scene": "ordinary", "Block": 35, "Run": 3},
    "FirstPositionRequiringCompleteReceipt": {"Scene": "ordinary", "Block": 35, "Run": 4, "Ordinal": 140},
    "OriginalProcessesSHA256": Hash(Summary),
    "OriginalUnfinishedGzipSHA256": Hash(Stream),
    "RecoveredClosedGzipSHA256": Hash(Stream + Tail),
    "IdenticalDecompressedCsvSHA256": Hash(Data),
    "OriginalGzipBytes": len(Stream),
    "AppendedGzipFooterBytesHex": Tail.hex(),
    "Recovery": "Keep every original gzip byte, append an empty final deflate block and the original data CRC/length in a separate copy, verify complete decompressed CSV bytes and every recorded native count and nanosecond sum. Resume the existing seeded collector without launching its 139 completed positions."
}
(Base / "InterruptedPrefix.json").write_text(json.dumps(Receipt, indent=2)+"\n", encoding="utf-8")
print(json.dumps(Receipt))
