param(
 [Parameter(Mandatory=$true)][string] $WorkspacePath,
 [Parameter(Mandatory=$true)][string] $Candidate,
 [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string] $ExpectedHash
)
$ErrorActionPreference='Stop'
$RootStudy='C:/Sandbox/GargantuanSpatialStabilizationPerformance-20261128'
$Predecessor = Get-Content -LiteralPath (Join-Path $RootStudy 'FixedEvents.jsonl') | ForEach-Object { ConvertFrom-Json $_ }
if(-not ($Predecessor | Where-Object { $_.Event -eq 'Exit' -and $_.Scene -eq 'rigid' -and $_.Code -eq 0 })) { throw 'First independently registered cohort has not finished' }
$Study=Join-Path $RootStudy 'Repaired'
$Historical='C:/Users/aiden/AppData/Local/Temp/SpatialConstructionProduction-20261127/EditorHost-284443879/gargantuan.exe'
if((Get-FileHash -LiteralPath $Historical -Algorithm SHA256).Hash -ne '0f43758828929e453d054689e81524a662e75c9e26d8ec4d4a4089396795d4aa'){throw 'Historical executable identity differs'}
if((Get-FileHash -LiteralPath $Candidate -Algorithm SHA256).Hash -ne $ExpectedHash){throw 'Candidate executable identity differs'}
$TemporaryProjects=Join-Path $Study 'FixedScratch'
New-Item -ItemType Directory -Force -Path $TemporaryProjects | Out-Null
$env:TEMP=$TemporaryProjects
$env:TMP=$TemporaryProjects
Set-Location -LiteralPath $WorkspacePath
$Events=Join-Path $Study 'FixedEvents.jsonl'
if(Test-Path -LiteralPath $Events){throw 'Fixed qualification was already started'}
foreach($Case in @(@('ordinary',64,1024),@('rigid',16,768))) {
 $Scene=$Case[0]
 $Directory=Join-Path $Study "Fixed-$Scene"
 if(Test-Path -LiteralPath $Directory){throw 'Original fixed output must be fresh'}
 [pscustomobject]@{Event='Start';Scene=$Scene;TimeUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress | Add-Content -LiteralPath $Events
 & python -B tests/SpatialConstructionPrecision.py --baseline $Historical --current $Candidate --output $Directory --scene $Scene --blocks $Case[1] --frames $Case[2] --warmup 192 --poll-ms 4 --engine-mask 0xffff0000 --main-cpu 24 --controller-cpu 8 --seed 20261127
 $Result=$LASTEXITCODE
 [pscustomobject]@{Event='Exit';Scene=$Scene;Code=$Result;TimeUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress | Add-Content -LiteralPath $Events
 if($Result){exit $Result}
}
