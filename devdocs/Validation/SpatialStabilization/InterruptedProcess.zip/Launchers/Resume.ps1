param([Parameter(Mandatory=$true)] [string] $WorkspacePath)
$ErrorActionPreference = 'Stop'
$Area = 'C:/Sandbox/GargantuanSpatialStabilizationPerformance-20261128/Repaired'
$Final = Join-Path $Area 'Completion'
$Events = Join-Path $Final 'FixedEvents.jsonl'
$Historical = 'C:/Users/aiden/AppData/Local/Temp/SpatialConstructionProduction-20261127/EditorHost-284443879/gargantuan.exe'
$Candidate = 'C:/Users/aiden/AppData/Local/Temp/SpatialStabilizationDelivery-20261128/Products/Normal-562a0fe7b/gargantuan.exe'
if ((Get-FileHash -LiteralPath $Historical).Hash -ne '0f43758828929e453d054689e81524a662e75c9e26d8ec4d4a4089396795d4aa') { throw 'Historical hash mismatch' }
if ((Get-FileHash -LiteralPath $Candidate).Hash -ne '1378d39488e60a5c2120d94ab9e2b753889d5aba4b62f68f26763e7d34028adc') { throw 'Repaired hash mismatch' }
$env:TEMP = Join-Path $Area 'FixedScratch'
$env:TMP = $env:TEMP
Set-Location -LiteralPath $WorkspacePath
$Options = @('--baseline',$Historical,'--current',$Candidate,'--warmup','192','--poll-ms','4','--engine-mask','0xffff0000','--main-cpu','24','--controller-cpu','8','--seed','20261127')
function WriteEvent([string] $Name, [string] $Scene, $Code) {
  $Event = [ordered]@{Event=$Name; Scene=$Scene; TimeUtc=[DateTime]::UtcNow.ToString('o')}
  if ($null -ne $Code) { $Event.Code = $Code }
  $Event | ConvertTo-Json -Compress | Add-Content -LiteralPath $Events
}
if (Test-Path -LiteralPath (Join-Path $Final 'Fixed-ordinary')) { throw 'The suffix has already started' }
WriteEvent 'ResumeAtOrdinal140' 'ordinary' $null
& python -B tests/SpatialOrdinaryResume.py --prior (Join-Path $Area 'ClosedPrefix') --recovery-log (Join-Path $Final 'Recovery.jsonl') --output (Join-Path $Final 'Fixed-ordinary') --scene ordinary --blocks 64 --frames 1024 @Options
$Result = $LASTEXITCODE
WriteEvent 'Exit' 'ordinary' $Result
if ($Result) { exit $Result }
WriteEvent 'Start' 'rigid' $null
& python -B tests/SpatialConstructionPrecision.py --output (Join-Path $Final 'Fixed-rigid') --scene rigid --blocks 16 --frames 768 @Options
$Result = $LASTEXITCODE
WriteEvent 'Exit' 'rigid' $Result
exit $Result
